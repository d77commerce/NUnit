﻿using NUnit.Framework;

namespace FightingArena
{
    [TestFixture]
    public class HeroTests
    {
        [Test]
        public void Test1()
        {

        }
    }
}